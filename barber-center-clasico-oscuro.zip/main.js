/* ============================================================================
   BARBER CENTER — main.js
   Vanilla JS, sin dependencias de build. GSAP/ScrollTrigger por <script> (CDN local).
   La web funciona sin JS: aquí solo enriquecemos.
   ============================================================================ */
(function () {
  "use strict";

  var DATA = window.__BARBER__ || {};
  var hasGSAP = typeof window.gsap !== "undefined";

  /* Envuelve cada init: si uno falla, no tumba al resto. */
  function safe(fn, name) {
    try { fn(); } catch (e) { if (window.console) console.warn("[barber] " + name + " falló:", e); }
  }

  function $(s, c) { return (c || document).querySelector(s); }
  function $all(s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); }

  /* ----------------------------------------------------------------------
     1) DATOS DESDE manifest.js  (data-bind)
  ---------------------------------------------------------------------- */
  function bindData() {
    var booksy = DATA.booksyUrl || "#";
    var igUrl = DATA.instagram ? ("https://instagram.com/" + DATA.instagram) : "#";
    var telHref = DATA.phoneLink ? ("tel:" + DATA.phoneLink) : "#";

    $all("[data-bind]").forEach(function (el) {
      var key = el.getAttribute("data-bind");
      switch (key) {
        case "booksy": el.setAttribute("href", booksy); break;
        case "instagram-link": el.setAttribute("href", igUrl); break;
        case "phone":
          if (el.tagName === "A") el.setAttribute("href", telHref);
          if (el.tagName === "A" && /^\s*(Llamar|Call)/.test(el.textContent)) {
            /* deja el texto bilingüe tal cual; solo actualiza el href */
          } else if (el.tagName !== "A") {
            el.textContent = DATA.phoneDisplay || el.textContent;
          }
          break;
        case "booksyReviews": el.textContent = DATA.booksyReviews || el.textContent; break;
        case "googleRating": el.textContent = DATA.googleRating || el.textContent; break;
        case "googleReviews": el.textContent = DATA.googleReviews || el.textContent; break;
        case "hoursShort": el.textContent = DATA.hoursShort || el.textContent; break;
        case "hoursClosed":
          if (DATA.hoursClosed) { el.setAttribute("data-es", DATA.hoursClosed); el.textContent = DATA.hoursClosed; }
          break;
        case "address": el.textContent = DATA.address || el.textContent; break;
        case "city": el.textContent = DATA.city || el.textContent; break;
      }
    });
  }

  /* ----------------------------------------------------------------------
     2) SPLASH — doble red de seguridad (CSS + JS)
  ---------------------------------------------------------------------- */
  function splash() {
    var el = $("[data-splash]");
    if (!el) return;
    function hide() { el.classList.add("is-hidden"); }
    /* CSS ya lo oculta a los ~5s; JS lo refuerza por si la animación no dispara */
    window.setTimeout(hide, 5000);
    el.addEventListener("click", hide);
  }

  /* ----------------------------------------------------------------------
     3) CURSOR personalizado (con etiqueta data-cursor)
  ---------------------------------------------------------------------- */
  function cursor() {
    var cur = $(".cursor");
    if (!cur) return;
    if (window.matchMedia("(hover:none),(pointer:coarse)").matches) return;
    var label = $(".cursor-label", cur);
    var x = 0, y = 0, cx = 0, cy = 0, raf;

    function loop() {
      cx += (x - cx) * 0.2; cy += (y - cy) * 0.2;
      cur.style.transform = "translate(" + cx + "px," + cy + "px) translate(-50%,-50%)";
      raf = window.requestAnimationFrame(loop);
    }
    window.addEventListener("mousemove", function (e) {
      x = e.clientX; y = e.clientY; cur.style.opacity = "1";
      if (!raf) loop();
    });
    document.addEventListener("mouseleave", function () { cur.style.opacity = "0"; });

    var LABELS = {
      es: { reservar: "Reservar", ver: "Ver", llamar: "Llamar", arriba: "Arriba" },
      en: { reservar: "Book", ver: "View", llamar: "Call", arriba: "Top" }
    };
    $all("[data-cursor]").forEach(function (el) {
      el.addEventListener("mouseenter", function () {
        cur.classList.add("is-hover");
        var key = el.getAttribute("data-cursor");
        var lang = document.documentElement.lang === "en" ? "en" : "es";
        label.textContent = (LABELS[lang] && LABELS[lang][key]) || "";
      });
      el.addEventListener("mouseleave", function () {
        cur.classList.remove("is-hover"); label.textContent = "";
      });
    });
  }

  /* ----------------------------------------------------------------------
     4) IDIOMA ES / EN  (data-es / data-en, persiste en localStorage)
  ---------------------------------------------------------------------- */
  function lang() {
    var KEY = "barber_lang";
    var btns = $all(".lang [data-lang]");

    function apply(l) {
      document.documentElement.lang = l;
      $all("[data-es]").forEach(function (el) {
        var val = el.getAttribute(l === "en" ? "data-en" : "data-es");
        if (val != null) el.textContent = val;
      });
      btns.forEach(function (b) { b.classList.toggle("is-active", b.getAttribute("data-lang") === l); });
      try { localStorage.setItem(KEY, l); } catch (e) {}
    }

    var saved;
    try { saved = localStorage.getItem(KEY); } catch (e) {}
    if (saved === "en") apply("en");

    btns.forEach(function (b) {
      b.addEventListener("click", function () { apply(b.getAttribute("data-lang")); });
    });
  }

  /* ----------------------------------------------------------------------
     5) MENÚ móvil (burger)
  ---------------------------------------------------------------------- */
  function nav() {
    var burger = $("#burger"), links = $("#navLinks");
    if (!burger || !links) return;
    function toggle(open) {
      var willOpen = open != null ? open : !links.classList.contains("is-open");
      links.classList.toggle("is-open", willOpen);
      burger.setAttribute("aria-expanded", String(willOpen));
    }
    burger.addEventListener("click", function () { toggle(); });
    $all("a", links).forEach(function (a) { a.addEventListener("click", function () { toggle(false); }); });
  }

  /* ----------------------------------------------------------------------
     6) Header con estado al hacer scroll
  ---------------------------------------------------------------------- */
  function header() {
    var h = $("#header");
    if (!h) return;
    function update() { h.classList.toggle("is-scrolled", window.scrollY > 30); }
    update();
    window.addEventListener("scroll", update, { passive: true });
  }

  /* ----------------------------------------------------------------------
     7) Iniciales de avatares (equipo)
  ---------------------------------------------------------------------- */
  function avatars() {
    $all(".avatar[data-initials]").forEach(function (a) {
      if (!a.textContent.trim()) a.textContent = a.getAttribute("data-initials") || "";
    });
  }

  /* ----------------------------------------------------------------------
     8) REVEAL  (IntersectionObserver + GSAP opcional + red de seguridad 6s)
  ---------------------------------------------------------------------- */
  function reveals() {
    var items = $all(".reveal");
    if (!items.length) return;

    function show(el) { el.classList.add("is-in"); }

    if ("IntersectionObserver" in window) {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (e) {
          if (e.isIntersecting) { show(e.target); io.unobserve(e.target); }
        });
      }, { threshold: 0.05, rootMargin: "0px 0px -8% 0px" });
      items.forEach(function (el) { io.observe(el); });
    } else {
      items.forEach(show);
    }

    /* Red de seguridad: pase lo que pase, a los 6s todo es visible */
    window.setTimeout(function () { items.forEach(show); }, 6000);
  }

  /* ----------------------------------------------------------------------
     9) Parallax sutil del hero (solo si GSAP + ScrollTrigger)
  ---------------------------------------------------------------------- */
  function heroParallax() {
    if (!hasGSAP || !window.ScrollTrigger) return;
    if (window.matchMedia("(prefers-reduced-motion:reduce)").matches) return;
    window.gsap.registerPlugin(window.ScrollTrigger);
    var img = $(".hero-media img");
    if (!img) return;
    window.gsap.to(img, {
      yPercent: 14, ease: "none",
      scrollTrigger: { trigger: ".hero", start: "top top", end: "bottom top", scrub: true }
    });
  }

  /* ----------------------------------------------------------------------
     INIT
  ---------------------------------------------------------------------- */
  function init() {
    safe(bindData, "bindData");
    safe(splash, "splash");
    safe(cursor, "cursor");
    safe(lang, "lang");
    safe(nav, "nav");
    safe(header, "header");
    safe(avatars, "avatars");
    safe(reveals, "reveals");
    safe(heroParallax, "heroParallax");
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
