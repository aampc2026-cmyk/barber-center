# Barber Center — Web (demo)

Demostración de web para **Barber Center** (Adeje, Tenerife). Es una web de una
sola página, bilingüe **español / inglés**, pensada para móvil y para que todas
las reservas lleven a vuestro **Booksy**.

> Esta es una **maqueta de muestra**. Algunos textos (reseñas, especialidad de
> cada barbero) y las fotos son representativos y se ajustan con vosotros antes
> de publicar.

---

## 1. Cómo verla

Haz doble clic en **`index.html`** y se abrirá en tu navegador. No necesita
internet para verse (salvo el mapa y las fuentes).

## 2. Cómo cambiar los datos del negocio

Casi todo lo importante (teléfono, enlace de Booksy, dirección, horario,
Instagram, reseñas) se edita en **un solo sitio**:

Abre **`lib/manifest.js`** con el Bloc de notas y cambia **solo el texto entre
comillas**. Por ejemplo:

```js
phoneDisplay: "922 07 54 60",
booksyUrl: "https://booksy.com/es-es/21867_barber-center_...",
hoursShort: "Mar – Sáb · 10:00 → 19:00",
```

No toques los nombres de la izquierda ni los símbolos `{ } ; "`.

## 3. Cómo cambiar las fotos

Las imágenes están en la carpeta **`assets/img/`**. Sustituye los archivos por
los vuestros **manteniendo el mismo nombre** (por ejemplo `hero-shop.webp` para
la foto grande de portada). Recomendado: formato **.webp** y horizontal.

Las fotos de muestra actuales son de bancos libres; sus créditos están en
`creditos.html`. Al poner vuestras fotos reales, ese aviso deja de ser
necesario.

## 4. Cómo publicarla en internet (Hostinger)

1. Entra en tu **hPanel** de Hostinger → **Administrador de archivos**.
2. Entra en la carpeta `public_html`.
3. **Sube todo el contenido de esta carpeta** (arrastra `index.html`,
   `styles.css`, `main.js`, `creditos.html`, `.htaccess` y las carpetas `lib/`
   y `assets/`).
4. Listo: tu web estará en tu dominio.

> Si después de actualizar algo no ves los cambios, pulsa **Ctrl + F5**
> (o ⌘ + Shift + R en Mac) para refrescar sin caché.

## 5. Qué incluye

- Portada con vuestra valoración (5,0★ Booksy · 4,8★ Google).
- Servicios y precios.
- Equipo de 6 barberos.
- Galería.
- Reseñas.
- Sección de reserva con botón a Booksy, teléfono, horario y mapa.
- Botón **ES / EN** para clientes de habla inglesa (turismo).
- Preparada para Google (SEO local, datos de barbería, compartir en redes).

## 6. Qué debéis confirmar

- Dirección exacta (nº 28 Local 2 vs nº 30) y código postal.
- Especialidad de cada barbero (color, afeitado…).
- Si queréis reseñas reales concretas en lugar de las de muestra.
- Precios actualizados.
